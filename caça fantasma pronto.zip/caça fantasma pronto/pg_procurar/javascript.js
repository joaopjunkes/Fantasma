const form = document.querySelector('form')
const foto = document.getElementById('foto')
const nome = document.getElementById('nome')
const popularidade = document.getElementById('popularidade')
const descricao = document.getElementById('descricao')

const personagens = [
    ['Gengar', 'Popularidade: 10', 'Caracteristicas: Fantasma malefico, Natureza malefica e horripilante.<br> Onde Encontrar: Vive escondido nas florestas.', 'https://assets.pokemon.com/assets/cms2/img/pokedex/full/094.png'],
    ['Fantasmático', 'Popularidade: 6', 'Caracteristicas: Fantasma heroíco, Natureza desconhecida porem luta pelo bem.<br> Onde Encontrar: Em cenas de crimes.', 'https://assets.stickpng.com/images/5a944af99fc609199d0fef16.png'],
    ['Gasparzinho', 'Popularidade: 8', 'Caracteristicas: Fantasminha amigável, Natureza amorosa e compassiva.<br>Onde Encontrar: Sem lugar definido.', 'https://1.bp.blogspot.com/-a9YCrOiU1Fg/VG1fVt50izI/AAAAAAAAh8E/GXQH9G0ErjU/w680/Gasparsinho-em-png-queroimagm-cei%C3%A7a-crispim-04.png'],
    ['Murta Que Geme', 'Popularidade: 4', 'Caracteristicas: Fantasma neutra, Natureza melancólica.<br> Onde Encontrar: No banheiro, sempre chorando....', 'https://pm1.aminoapps.com/6279/826486bb62978f0d781ec008a9c94703742f7f91_00.jpg'],
    ['Holandês Voador', 'Popularidade: 6', 'Caracteristicas: Fantasma malefico, Natureza malefica e horripilante.<br> Onde Encontrar: Navegando em alto mar.', 'https://i.pinimg.com/originals/42/c1/b3/42c1b3405c0c719634bcb0b9bb131d9e.png'],
]

form.onsubmit = (evento) => {
    const inputs = new FormData(evento.target)
    const nomeDoPersonagem = inputs.get('busca').toUpperCase()
    let encontrouPersonagem = false

    for (let i = 0; i < personagens.length; i++) {
        if (nomeDoPersonagem == personagens[i][0].toUpperCase()) {
            nome.textContent = personagens[i][0]
            popularidade.textContent = personagens[i][1]
            descricao.innerHTML = personagens[i][2]
            foto.src = personagens[i][3]
            encontrouPersonagem = true
        }
    }

    !encontrouPersonagem && alert('Personagem não encontrado!')
    return false
}