const canvas = document.getElementById('canvas');
const context = canvas.getContext('2d');

const jogador = {
  x: 50,
  y: 50,
  raio: 20,
  cor: '#00ccff'
};

let inimigos = [];

// Função para desenhar o jogador no canvas
function desenharJogador() {
  context.beginPath();
  context.arc(jogador.x, jogador.y, jogador.raio, 0, Math.PI * 2);
  context.fillStyle = jogador.cor;
  context.fill();
  context.closePath();
}

// Função para desenhar os inimigos no canvas
function desenharInimigos() {
  inimigos.forEach(inimigo => {
    context.beginPath();
    context.arc(inimigo.x, inimigo.y, inimigo.raio, 0, Math.PI * 2);
    context.fillStyle = inimigo.cor;
    context.fill();
    context.closePath();
  });
}

// Função para verificar colisões entre o jogador e os inimigos
function colisao() {
  for (let i = 0; i < inimigos.length; i++) {
    const inimigo = inimigos[i];
    const dx = jogador.x - inimigo.x;
    const dy = jogador.y - inimigo.y;
    const distancia = Math.sqrt(dx * dx + dy * dy);

    if (distancia < jogador.raio + inimigo.raio) {
      gameOver();
      return;
    }
  }
}

// Função para verificar colisões entre inimigos
function verificarColisao(novoInimigo) {
  for (let i = 0; i < inimigos.length; i++) {
    const inimigoExistente = inimigos[i];
    const dx = novoInimigo.x - inimigoExistente.x;
    const dy = novoInimigo.y - inimigoExistente.y;
    const distancia = Math.sqrt(dx * dx + dy * dy);

    if (distancia < novoInimigo.raio + inimigoExistente.raio) {
      return true; // Colisão detectada, não adicionar o novo inimigo
    }
  }
  return false; // Não há colisão, pode adicionar o novo inimigo
}

// Função de atualização que é chamada a cada frame do jogo
function atualizar() {
  context.clearRect(0, 0, canvas.width, canvas.height);
  desenharJogador();
  desenharInimigos();
  moverInimigos();
  colisao();
  requestAnimationFrame(atualizar);
}

// Função para mover os inimigos em direção ao jogador
function moverInimigos() {
  inimigos.forEach(inimigo => {
    const dx = jogador.x - inimigo.x;
    const dy = jogador.y - inimigo.y;
    const distancia = Math.sqrt(dx * dx + dy * dy);

    const velocidade = 2;
    const vx = (velocidade / distancia) * dx;
    const vy = (velocidade / distancia) * dy;

    inimigo.x += vx;
    inimigo.y += vy;
  });
}

// Função para mover o jogador com base no movimento do mouse
function moverJogador(event) {
  const retangulo = canvas.getBoundingClientRect();
  jogador.x = event.clientX - retangulo.left;
  jogador.y = event.clientY - retangulo.top;
}

// Adiciona um listener de evento para detectar o movimento do mouse
canvas.addEventListener('mousemove', moverJogador);

// Adiciona um novo inimigo a cada 2 segundos
setInterval(() => {
  adicionarInimigo();
}, 2000);

// Chama a função de atualização para iniciar o jogo
atualizar();

// Função para adicionar um novo inimigo ao array
function adicionarInimigo() {
  const raio = 15;
  let x, y, cor;
  let colisaoDetectada = true;

  while (colisaoDetectada) {
    x = Math.random() * (canvas.width - raio * 2) + raio;
    y = Math.random() * (canvas.height - raio * 2) + raio;
    cor = '#ff0000';

    const novoInimigo = { x, y, raio, cor };
    colisaoDetectada = verificarColisao(novoInimigo);
  }

  inimigos.push({ x, y, raio, cor });
}

// Função para encerrar o jogo e mostrar a mensagem de game over
function gameOver() {
  alert('Você foi capturado! Jogo perdido.');
  reiniciarJogo();
}

// Função para reiniciar o jogo
function reiniciarJogo() {
  jogador.x = 50;
  jogador.y = 50;
  inimigos = [];
}
